for i in range(5):
    for j in range(i):
        print(" ",end="")
    for j in range(5,i,-1):
        print("*",end="")
    print("");
    
for i in range(6):
    for j in range(5,i,-1):
        print(" ",end="")
    for j in range(i):
        print("*",end="")
    
    print("");
    
for i in range(1,6):
    for j in range(i):
        if j == 0 or j == i-1:
            print("*",end="");
        else:
            if i != 5:
                print(" ",end="")
            else:
                print("*",end="");
    print()
    
for i in range(0,6):
    for j in range(5,5-i,-1):
        print(j,end="")
    print()

for i in range(0,6):
    for j in range(i):
        print(j+1,end="")
    print()

for i in range(0,6):
    for j in range(i):
        print(i,end="")
    print()

for i in range(5,0,-1):
    for j in range(1,i+1):
        print(j,end="")
    print()
    
total_rows = 9  
for i in range(1, total_rows + 1):
    print(" " * (total_rows - i), end="")
        
    for j in range(i, i * 2):
        print(j % 10, end="")
        
    for j in range(i * 2 - 2, i - 1, -1):
        print(j % 10, end="")
        
    print() 
    
rows=9

for i in range(1,rows + 1):
    print(" " * (rows-i),end="")
    for j in range (i,i *2):
        print(j%10,end="")
    for j in range(i*2-2,i-1,-1):
        print(j%10,end="")
    print()
    
    