#include <iostream>
using namespace std;

class Time {
private:
    int hour, minute, second;

public:
    // Constructor to initialize the time
    Time(int h = 0, int m = 0, int s = 0) : hour(h), minute(m), second(s) {}

    // Overloading the + operator
    Time operator+(int seconds) const {
        Time newTime = *this;
        newTime.second += seconds;
        while (newTime.second >= 60) {
            newTime.second -= 60;
            newTime.minute++;
            if (newTime.minute >= 60) {
                newTime.minute -= 60;
                newTime.hour++;
                if (newTime.hour >= 24) {
                    newTime.hour -= 24;
                }
            }
        }
        return newTime;
    }

    // Overloading the - operator
    Time operator-(int seconds) const {
        Time newTime = *this;
        newTime.second -= seconds;
        while (newTime.second < 0) {
            newTime.second += 60;
            newTime.minute--;
            if (newTime.minute < 0) {
                newTime.minute += 60;
                newTime.hour--;
                if (newTime.hour < 0) {
                    newTime.hour += 24;
                }
            }
        }
        return newTime;
    }

    // Overloading the = operator
    Time& operator=(const Time& other) {
        if (this != &other) {
            hour = other.hour;
            minute = other.minute;
            second = other.second;
        }
        return *this;
    }

    // Overloading the < operator
    bool operator<(const Time& other) const {
        if (hour < other.hour) return true;
        if (hour == other.hour && minute < other.minute) return true;
        if (hour == other.hour && minute == other.minute && second < other.second) return true;
        return false;
    }

    // Overloading the <= operator
    bool operator<=(const Time& other) const {
        return *this < other || *this == other;
    }

    // Overloading the > operator
    bool operator>(const Time& other) const {
        return !(*this <= other);
    }

    // Overloading the >= operator
    bool operator>=(const Time& other) const {
        return !(*this < other);
    }

    // Overloading the == operator
    bool operator==(const Time& other) const {
        return (hour == other.hour && minute == other.minute && second == other.second);
    }

    // Overloading the != operator
    bool operator!=(const Time& other) const {
        return !(*this == other);
    }

    // Overloading the pre-increment operator
    Time& operator++() {
        *this = *this + 1;
        return *this;
    }

    // Overloading the post-increment operator
    Time operator++(int) {
        Time temp = *this;
        ++(*this);
        return temp;
    }

    // Overloading the pre-decrement operator
    Time& operator--() {
        *this = *this - 1;
        return *this;
    }

    // Overloading the post-decrement operator
    Time operator--(int) {
        Time temp = *this;
        --(*this);
        return temp;
    }

    // Function to display the time
    void display() const {
        cout << (hour < 10 ? "0" : "") << hour << ":"
             << (minute < 10 ? "0" : "") << minute << ":"
             << (second < 10 ? "0" : "") << second << endl;
    }
};

int main() {
    Time t1(23, 59, 50);
    Time t2;

    t2 = t1 + 15;
    cout << "t1 + 15 seconds: ";
    t2.display();

    t2 = t1 - 70;
    cout << "t1 - 70 seconds: ";
    t2.display();

    cout << "t1 == t2: " << (t1 == t2 ? "True" : "False") << endl;
    cout << "t1 != t2: " << (t1 != t2 ? "True" : "False") << endl;
    cout << "t1 < t2: " << (t1 < t2 ? "True" : "False") << endl;
    cout << "t1 <= t2: " << (t1 <= t2 ? "True" : "False") << endl;
    cout << "t1 > t2: " << (t1 > t2 ? "True" : "False") << endl;
    cout << "t1 >= t2: " << (t1 >= t2 ? "True" : "False") << endl;

    cout << "Pre-increment t1: ";
    (++t1).display();

    cout << "Post-increment t1: ";
    (t1++).display();
    t1.display();

    cout << "Pre-decrement t1: ";
    (--t1).display();

    cout << "Post-decrement t1: ";
    (t1--).display();
    t1.display();

    return 0;
}
