#include <iostream>
using namespace std;

class Matrix {
private:
    int rows, cols;
    int** data;

public:
    // Constructor to initialize the matrix with given dimensions
    Matrix(int r, int c) : rows(r), cols(c) {
        data = new int*[rows];
        for (int i = 0; i < rows; ++i) {
            data[i] = new int[cols];
            for (int j = 0; j < cols; ++j) {
                data[i][j] = i + j; // Initializing with some values
            }
        }
    }

    // Destructor to free the allocated memory
    ~Matrix() {
        for (int i = 0; i < rows; ++i) {
            delete[] data[i];
        }
        delete[] data;
    }

    // Overloading the << operator to display the matrix
    friend ostream& operator<<(ostream& os, const Matrix& mat);

    // Function to set a value in the matrix (optional)
    void setValue(int r, int c, int value) {
        if (r >= 0 && r < rows && c >= 0 && c < cols) {
            data[r][c] = value;
        }
    }
};

// Definition of the overloaded << operator
ostream& operator<<(ostream& os, const Matrix& mat) {
    for (int i = 0; i < mat.rows; ++i) {
        for (int j = 0; j < mat.cols; ++j) {
            os << mat.data[i][j] << " ";
        }
        os << endl;
    }
    return os;
}

int main() {
    Matrix m1(3, 3); // Creating a 3x3 matrix object
    cout << "Matrix m1:" << endl;
    cout << m1; // Using the overloaded << operator to display the matrix

    return 0;
}
